# FreeETHSpin
Free ETH Spinner


![alt text](https://raw.githubusercontent.com/kadal15/bukan-untuk-umum/master/Screenshot_2019-03-22-08-04-38-52.png)

<dl>
  <dt>Deskripsi</dt>
  <dd>Ini adalah Tools Untuk Nuyul Aplikasi Free ETH Spinner</dd>

  <dt>Cara Install</dt>
</dl>
<pre><code>apt update && apt upgrade -y
pkg install nano 
pkg install git
pkg install php
git clone https://github.com/kadal15/FreeETHSpin.git
cd FreeETHSpin
nano config.php
php ETHSpin.php
</code></pre>
<dl>
  <dd>Edit Config.php</dd>
  <dd>ganti dengan data punya anda</dd>
</dl>
<pre><code>
&lt;?php
//Email 
$email = "xxxxxxxxxxxx@gmail.com";
//Device ID
$deviceid = "xxxxxxxxxxxxxxxxxxxxxxxxxxxx";
?&gt;
</code></pre>
<dl>
  <dt>Kunjungi Juga</dt>
  <dd>Blog https://jejakatutorial-termux.blogspot.com</dd>
  <dd>Youtube https://www.youtube.com/channel/UCn5d8Xbp0yt-SWTmxwtayvQ</dd>
  
  <dt>Donation</dt>
  <dd>BTC : 18961sqv9fPuBcEbbi1gHub8ydWePB8yaG</dd>
  <dd>LTC : LNRkk6o9h1Rh98sDW8byeH9HbeUHwNohDu</dd>
  <dd>Doge : DJG4YG3ARUkSt9e5xvHvSS3faVx3v1HM9p</dd>
  <dd>Paypal : lutfiainunnajih@gmail.com</dd>
</dl>
