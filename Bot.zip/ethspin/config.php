<?php

//Email 
$email = "emailmaulanayusuf@gmail.com";

//Device ID
$deviceid = "83617B5BFCBA41A8";

?>
