# FreeLTCSpin
Free LTC Spinner Bot


![alt text](https://raw.githubusercontent.com/kadal15/bukan-untuk-umum/master/Screenshot_2019-03-22-11-11-48-21.png)

<dl>
  <dt>Deskripsi</dt>
  <dd>Ini adalah Tools Untuk Nuyul Aplikasi Free LTC Spinner</dd>

  <dt>Cara Install</dt>
</dl>
<pre><code>apt update && apt upgrade -y
pkg install nano 
pkg install git
pkg install php
git clone https://github.com/kadal15/FreeLTCSpin.git
cd FreeLTCSpin
nano config.php
php LTCSpin.php
</code></pre>
<dl>
  <dd>Edit Config.php</dd>
  <dd>ganti dengan data punya anda</dd>
</dl>
<pre><code>
&lt;?php
//Email 
$email = "xxxxxxxxxxxx@gmail.com";
//Device ID
$deviceid = "xxxxxxxxxxxxxxxxxxxxxxxxxxxx";
?&gt;
</code></pre>
<dl>
  <dt>Kunjungi Juga</dt>
  <dd>Blog https://jejakatutorial-termux.blogspot.com</dd>
  <dd>Youtube https://www.youtube.com/channel/UCn5d8Xbp0yt-SWTmxwtayvQ</dd>
  
  <dt>Donation</dt>
  <dd>BTC : 18961sqv9fPuBcEbbi1gHub8ydWePB8yaG</dd>
  <dd>LTC : LNRkk6o9h1Rh98sDW8byeH9HbeUHwNohDu</dd>
  <dd>Doge : DJG4YG3ARUkSt9e5xvHvSS3faVx3v1HM9p</dd>
  <dd>Paypal : lutfiainunnajih@gmail.com</dd>
</dl>
