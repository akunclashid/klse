<?php

//Email
$email = "emailmaulanayusuf@gmail.com";

//Device Id
$deviceid = "83617B5BFCBA41A8";

?>
